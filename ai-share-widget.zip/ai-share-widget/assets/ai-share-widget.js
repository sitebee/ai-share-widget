/**
 * AI Share Widget JavaScript
 * Enhanced functionality with analytics, error handling, and accessibility
 */

(function() {
    'use strict';

    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        initializeAIShareWidget();
    });

    /**
     * Main initialization function
     */
    function initializeAIShareWidget() {
        try {
            const shareWidgets = document.querySelectorAll('.ai-share-wrapper');
            
            if (shareWidgets.length === 0) {
                return; // No widgets found, exit gracefully
            }

            shareWidgets.forEach(function(widget) {
                setupWidget(widget);
            });

            // Add keyboard navigation support
            setupKeyboardNavigation();
            
            // Add click tracking
            setupClickTracking();
            
            console.log('AI Share Widget: Initialized successfully');
            
        } catch (error) {
            console.error('AI Share Widget: Initialization error', error);
        }
    }

    /**
     * Setup individual widget functionality
     */
    function setupWidget(widget) {
        const buttons = widget.querySelectorAll('.ai-share-buttons a');
        
        // Add loading state management
        buttons.forEach(function(button) {
            button.addEventListener('click', function(e) {
                handleButtonClick(e, this);
            });
            
            // Add tooltip functionality
            addTooltip(button);
        });

        // Add widget-specific enhancements
        enhanceAccessibility(widget);
    }

    /**
     * Handle button click events
     */
    function handleButtonClick(event, button) {
        try {
            const platform = getPlatformFromButton(button);
            const url = button.href;
            
            // Track the click (you can integrate with Google Analytics, etc.)
            trackShare(platform, url);
            
            // Add visual feedback
            addClickFeedback(button);
            
            // Optional: Add confirmation for certain platforms
            if (shouldConfirmShare(platform)) {
                if (!confirm('This will open ' + platform + ' in a new tab. Continue?')) {
                    event.preventDefault();
                    return false;
                }
            }
            
        } catch (error) {
            console.error('AI Share Widget: Click handler error', error);
        }
    }

    /**
     * Extract platform name from button
     */
    function getPlatformFromButton(button) {
        const classList = button.className;
        const platformMatch = classList.match(/btn-(\w+)/);
        return platformMatch ? platformMatch[1] : 'unknown';
    }

    /**
     * Track sharing events (integrate with your analytics)
     */
    function trackShare(platform, url) {
        // Google Analytics 4 example
        if (typeof gtag !== 'undefined') {
            gtag('event', 'ai_share_click', {
                'platform': platform,
                'url': url,
                'event_category': 'AI Share Widget'
            });
        }
        
        // Console logging for debugging
        console.log('AI Share Widget: Share clicked', {
            platform: platform,
            url: url,
            timestamp: new Date().toISOString()
        });
        
        // Custom event for other tracking systems
        const customEvent = new CustomEvent('aiShareClick', {
            detail: {
                platform: platform,
                url: url
            }
        });
        document.dispatchEvent(customEvent);
    }

    /**
     * Add visual feedback on button click
     */
    function addClickFeedback(button) {
        button.style.transform = 'scale(0.95)';
        button.style.opacity = '0.8';
        
        setTimeout(function() {
            button.style.transform = '';
            button.style.opacity = '';
        }, 150);
    }

    /**
     * Check if platform requires confirmation
     */
    function shouldConfirmShare(platform) {
        // Add platforms that might need confirmation
        const confirmPlatforms = []; // e.g., ['whatsapp', 'linkedin']
        return confirmPlatforms.includes(platform);
    }

    /**
     * Setup keyboard navigation
     */
    function setupKeyboardNavigation() {
        document.addEventListener('keydown', function(e) {
            // Handle Enter and Space keys on share buttons
            if ((e.key === 'Enter' || e.key === ' ') && 
                e.target.classList.contains('ai-share-buttons')) {
                e.preventDefault();
                e.target.click();
            }
        });
    }

    /**
     * Setup click tracking and analytics
     */
    function setupClickTracking() {
        // Listen for all share button clicks
        document.addEventListener('click', function(e) {
            if (e.target.closest('.ai-share-buttons a')) {
                const button = e.target.closest('.ai-share-buttons a');
                const platform = getPlatformFromButton(button);
                
                // Send to analytics if available
                sendToAnalytics('share_button_click', {
                    platform: platform,
                    page_url: window.location.href,
                    page_title: document.title
                });
            }
        });
    }

    /**
     * Send events to analytics platforms
     */
    function sendToAnalytics(eventName, data) {
        // Google Analytics 4
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, data);
        }
        
        // Facebook Pixel
        if (typeof fbq !== 'undefined') {
            fbq('track', 'Share', data);
        }
        
        // Custom analytics endpoint
        if (window.aiShareWidgetConfig && window.aiShareWidgetConfig.analyticsEndpoint) {
            fetch(window.aiShareWidgetConfig.analyticsEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    event: eventName,
                    data: data,
                    timestamp: Date.now()
                })
            }).catch(function(error) {
                console.log('Analytics tracking failed:', error);
            });
        }
    }

    /**
     * Add tooltip functionality
     */
    function addTooltip(button) {
        const platform = getPlatformFromButton(button);
        const tooltips = {
            'chatgpt': 'Analyze this content with ChatGPT',
            'claude': 'Get insights from Claude AI',
            'perplexity': 'Explore with Perplexity AI',
            'whatsapp': 'Share via WhatsApp',
            'linkedin': 'Share on LinkedIn',
            'x': 'Analyze with X Grok',
            'googleai': 'Summarize with Google AI'
        };
        
        if (tooltips[platform]) {
            button.title = tooltips[platform];
        }
    }

    /**
     * Enhance accessibility features
     */
    function enhanceAccessibility(widget) {
        // Add skip link for screen readers
        const skipLink = document.createElement('a');
        skipLink.href = '#ai-share-end-' + Math.random().toString(36).substr(2, 9);
        skipLink.textContent = 'Skip sharing options';
        skipLink.className = 'screen-reader-text';
        skipLink.style.cssText = 'position: absolute; left: -9999px; width: 1px; height: 1px; overflow: hidden;';
        
        widget.insertBefore(skipLink, widget.firstChild);
        
        // Add end marker
        const endMarker = document.createElement('div');
        endMarker.id = skipLink.href.substring(1);
        endMarker.setAttribute('aria-hidden', 'true');
        widget.appendChild(endMarker);
    }

    /**
     * Error handling and fallback
     */
    function handleError(error, context) {
        console.error('AI Share Widget Error (' + context + '):', error);
        
        // Show user-friendly error message if needed
        if (window.aiShareWidgetConfig && window.aiShareWidgetConfig.showErrors) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'ai-share-widget-error';
            errorDiv.textContent = 'Sharing widget temporarily unavailable';
            
            const widgets = document.querySelectorAll('.ai-share-wrapper');
            widgets.forEach(function(widget) {
                widget.appendChild(errorDiv);
            });
        }
    }

    /**
     * Utility function to check if device is mobile
     */
    function isMobileDevice() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }

    /**
     * Public API for external integration
     */
    window.AIShareWidget = {
        init: initializeAIShareWidget,
        track: trackShare,
        version: '1.0.0'
    };

    // Handle page visibility changes (pause tracking when tab is hidden)
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            console.log('AI Share Widget: Page hidden, pausing tracking');
        } else {
            console.log('AI Share Widget: Page visible, resuming tracking');
        }
    });

})();
